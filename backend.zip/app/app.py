from flask import Flask

app = Flask()
app.config["DEBUG"] = True


